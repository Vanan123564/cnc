screen -S net -X quit
screen -S net python3 cnc.py
